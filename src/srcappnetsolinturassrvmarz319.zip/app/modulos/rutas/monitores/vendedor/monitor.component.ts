import { Component, OnInit, Input, ViewChild } from "@angular/core";
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators
} from "@angular/forms";
import { Router, ActivatedRoute, Params } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { TabStripComponent } from "@progress/kendo-angular-layout";
import {
  PanelBarExpandMode,
  PanelBarItemModel
} from "@progress/kendo-angular-layout";
import { NetsolinApp } from "../../../../shared/global";
import { MantbasicaService } from "../../../../services/mantbasica.service";
import { MantablasLibreria } from "../../../../services/mantbasica.libreria";
import { varGlobales } from "../../../../shared/varGlobales";
import { NetsolinService } from "../../../../services/netsolin.service";
import { DomSanitizer } from "@angular/platform-browser";
// import { RutaService } from '../../../../services/ruta.service';
import { AngularFirestore } from "@angular/fire/firestore";
import { Observable } from "rxjs";
import { APP_ID_RANDOM_PROVIDER } from "@angular/core/src/application_tokens";
import { containerRefreshEnd } from "@angular/core/src/render3/instructions";
import { map } from "rxjs/operators";

// import { NetsolinService } from '../../../../netsolinlibrerias/servicios/netsolin.service';

@Component({
  selector: "monitor-vendedor",
  templateUrl: "./monitor.component.html",
  styleUrls: ["./monitor.component.css"]
})
export class MonitorVendedorComponent implements OnInit {
  @ViewChild("tabstrip") public tabstrip: TabStripComponent;
  @Input() vparcaptura: string;
  @Input() vid: any;
  ptablab: string;
  paplica: string;
  pcampollave: string;
  pclase_nbs: string;
  pclase_val: string;
  pcamponombre: string;
  title: string;
  subtitle = "(Monitor)";
  varParam: string;
  rutamant: string;
  id: string;
  enerror = false;
  enlistaerror = false;
  listaerrores: any[] = [];
  message = "";
  cargando = false;
  resultados = false;
  crearcotiza = false;
  nom_empre: string;
  cargovendedor = false;
  regVendedor: any;
  cargocontacto = false;
  regContacto: any;
  vvalocategoria: string;
  filtrocontacto: string;
  filtroactividades: string = "";
  filtrocotiza: string = "";
  id_terconsulta: string;
  id_cliepoten: string;
  //ruta
  latrecorrido: number;
  lngrecorrido: number;
  lat: number;
  lng: number;
  init = false;
  visitas: Array<any> = [];
  visitas_cumplidas: Array<any> = [];
  visitas_pendientes: Array<any> = [];
  visitas_encurso: Array<any> = [];
  // Manejo panel de informacion
  infopanelselec: string;
  mostrarmensaje = false;
  collapse = false;
  esconder = false;
  //Enviar variable a graficos
  clasegrafico: string;
  linkmonivended: string = "";

  //rutas
  // visitas: any;
  cargovisitas = false;
  visitalocation: string;
  user: any = {};
  fechahoy = Date();
  recoano = "";
  recmes = "";
  recdia = "";
  resumano = "";
  resummes = "";
  resumdia = "";

  pcod_vended = "";

  pruebavininumbuscombog: string = "";
  llamabusqueda = false;
  pruellegallabusque: string = "";
  anosrecorrido: Array<any> = [];
  cargo_anosrecorido = false;
  historialrecorrido: Array<any> = [];
  cargo_historialrecorido = false;
  mesesrecorrido: Array<any> = [];
  cargo_mesesrecorido = false;
  diasrecorrido: Array<any> = [];
  cargo_diasrecorido = false;

  anosresum: Array<any> = [];
  cargo_anosresum = false;
  mesesresum: Array<any> = [];
  cargo_mesesresum = false;
  diasresum: Array<any> = [];
  cargo_diasresum = false;
  cierrecajaresum: Array<any> = [];
  cierrecajaefe: Array<any> = [];
  cierrecajachd: Array<any> = [];
  cierrecajapbcs: Array<any> = [];
  cierrecajapbtr: Array<any> = [];
  cargo_cierrecajaresum = false;
  recibosresum: Array<any> = [];
  cargo_recibosresum = false;
  consignacionesresum: Array<any> = [];
  cargo_consignacionesresum = false;
  visitasresum: Array<any> = [];
  cargo_visitasresum = false;
  visicumplidiaresum : Array<any> = [];
  constructor(
    private mantbasicaService: MantbasicaService,
    public vglobal: varGlobales,
    private libmantab: MantablasLibreria,
    public service: NetsolinService,
    private pf: FormBuilder,
    private router: Router,
    private activatedRouter: ActivatedRoute,
    private httpc: HttpClient,
    // public _ruta: RutaService,
    private sanitizer: DomSanitizer,
    private db: AngularFirestore
  ) {
    this.vglobal.mostrarbreadcrumbs = false;
    const fechahoy = new Date();
    const ano = fechahoy.getFullYear();
    const mes = fechahoy.getMonth() + 1;
    const dia = fechahoy.getDate();

    this.recoano = ano.toString();
    this.recmes = mes.toString();
    this.recdia = dia.toString();
    this.resumano = ano.toString();
    this.resummes = mes.toString();
    this.resumdia = dia.toString();
  }

  public onPanelChange(data: Array<PanelBarItemModel>): boolean {
    // // public onPanelChange(event: any) {
    // console.log("onPanelChange: ", event);
    // console.log("onPanelChange");
    // let focusedEvent: PanelBarItemModel = data.filter(
    //   item => item.focused === true
    // )[0];
    // console.log("focusedEvent.id: " + focusedEvent.id);
    // this.infopanelselec = focusedEvent.id;
    // if (focusedEvent.id !== "info") {
    //   this.selectedId = focusedEvent.id;
    //   console.log("selec id: ") + this.selectedId;
    //   //  this.router.navigate(["/" + focusedEvent.id]);
    // }

    return false;
  }
  public stateChange(data: Array<PanelBarItemModel>): boolean {
    // console.log("stateChange");
    // let focusedEvent: PanelBarItemModel = data.filter(
    //   item => item.focused === true
    // )[0];
    // console.log("focusedEvent.id: " + focusedEvent.id);

    // if (focusedEvent.id !== "info") {
    //   this.selectedId = focusedEvent.id;
    //   console.log("selec id: ") + this.selectedId;
    //   //  this.router.navigate(["/" + focusedEvent.id]);
    // }

    return false;
  }

  ngOnInit() {
    // console.log("en ngOnInit editregCliepotecial");
    this.activatedRouter.params.subscribe(parametros => {
      // this.varParam = parametros['varParam'];
      // this.id = parametros['id'];
      if (this.vparcaptura) {
        this.varParam = this.vparcaptura;
      } else {
        this.varParam = parametros["varParam"];
      }
      // this.id = parametros['id'];
      if (this.vparcaptura) {
        this.id = this.vid;
      } else {
        this.id = parametros["id"];
      }
      //ASEGURARSE QUE ESTA VAR PARAMETROS EN LOCALSTORAGE
      this.service.verificaVpar("CRMVENDEDOR", "VPARVENDEDORES").subscribe(
        resultado => {
          let lvart: any;
          lvart = localStorage.getItem(this.varParam);
          let lobjpar = JSON.parse(lvart);
          this.title = "Monitor vendedor";
          this.rutamant = "";
          this.paplica = "0";
          this.ptablab = "VENDEDORES";
          this.pcampollave = "cod_vended";
          this.pcamponombre = "detalle";
          this.pclase_nbs = "";
          this.pclase_val = "";
          let lvar = "";
          lvar = localStorage.getItem("DDT" + this.ptablab);
          this.mantbasicaService
            .getregTabla(
              this.id,
              this.ptablab,
              this.paplica,
              this.pcampollave,
              this.pclase_nbs,
              this.pclase_val,
              this.pcamponombre
            )
            .subscribe(
              regTabla => {
                var result0 = regTabla[0];
                if (typeof result0 != "undefined") {
                  this.enlistaerror = true;
                  this.listaerrores = regTabla;
                } else {
                  this.regVendedor = regTabla;
                  console.log("Trae regvendedor");
                  console.log(this.regVendedor);
                  this.filtroactividades =
                    "usuario='" + regTabla.cod_vended + "'";
                  this.linkmonivended =
                    "../EjeConsultaLis.wss?VRCod_obj=MONITORVENDTLTE&VCAMPO=*E*&VCONDI=Especial&VTEXTO=PVXICOD_VENDED='" +
                    regTabla.cod_vended +
                    "',PVXIANO=" +
                    "2018";
                  // this.paramtabvendrutas.cod_vended=regTabla.cod_vended;
                  this.service
                    .cargaPeriodoUsuar(regTabla.cod_vended)
                    .then(cargo => {
                      if (cargo) {
                        console.log(cargo, this.service);
                        this.pcod_vended = regTabla.cod_vended;
                        //cargar anos recorrido persona
                        this.getanosrecorrido(regTabla.cod_vended).subscribe(
                          (datosrec: any) => {
                            this.anosrecorrido = datosrec;
                            this.cargo_anosrecorido = true;
                            // console.log("aÑOS cargados ", this.anosrecorrido);
                          }
                        );
                        //cargar mese ano seleccionado recorrido persona
                        this.getmesesrecorrido(
                          regTabla.cod_vended,
                          this.recoano
                        ).subscribe((datosmes: any) => {
                          this.mesesrecorrido = datosmes;
                          this.cargo_mesesrecorido = true;
                          // console.log("meses 2019 cargados ", datosmes);
                        });
                        //cargar dias  ano mes seleccionado recorrido persona
                        this.getdiasrecorrido(
                          regTabla.cod_vended,
                          this.recoano,
                          this.recmes
                        ).subscribe((datosdias: any) => {
                          this.diasrecorrido = datosdias;
                          this.cargo_diasrecorido = true;
                          // console.log("dias 2019 cargados ", datosdias);
                        });
                        console.log('v 1');
                        //cargar historial  ano mes dia seleccionado recorrido persona
                        this.gethistorialrecorrido(
                          regTabla.cod_vended,
                          this.recoano,
                          this.recmes,
                          this.recdia
                        ).subscribe((datoshis: any) => {
                          console.log('datoshis', datoshis);
                          this.historialrecorrido = datoshis;
                          if (datoshis.lenght > 0) {
                            this.latrecorrido = datoshis[0].latitud;
                            this.lngrecorrido = datoshis[0].longitud;
                            this.cargo_historialrecorido = true;
                          }
                        });
                        console.log('v 2');
                        //para resumen diario
                        //cargar anos recorrido persona
                        this.getanosresumen(regTabla.cod_vended).subscribe(
                          (datosrec: any) => {
                            this.anosresum = datosrec;
                            this.cargo_anosresum = true;
                            console.log("aÑOS cargados resum ", this.anosresum);
                          }
                        );
                        console.log('v 3');
                        //cargar mese ano seleccionado recorrido persona
                        this.getmesesresumen(
                          regTabla.cod_vended,
                          this.resumano
                        ).subscribe((datosmesres: any) => {
                          this.mesesresum = datosmesres;
                          this.cargo_mesesresum = true;
                          console.log("meses 2019 cargados  resum", datosmesres);
                        });
                        console.log('v 4');
                        //cargar dias  ano mes seleccionado recorrido persona
                        this.getdiasresumen(
                          regTabla.cod_vended,
                          this.resumano,
                          this.resummes
                        ).subscribe((datosdias: any) => {
                          this.diasresum = datosdias;
                          this.cargo_diasresum = true;
                          console.log("dias 2019 cargados resume ", datosdias);
                        });
                        console.log('v 5');
                        //cargar ciere caja  ano mes dia seleccionado recorrido persona
                        this.actcierrecajaresumen();
                        this.actrecibosresumen();
                        this.actconsignacionesresumen();
                        //aqui
                        const lruta = `/personal/${regTabla.cod_vended}/rutas/${
                          this.service.id_ruta
                        }/periodos/${this.service.id_periodo}/visitas`;
                        console.log(lruta);
                        console.log(
                          `/personal/${regTabla.cod_vended}/rutas/${
                            this.service.id_ruta
                          }/periodos/${this.service.id_periodo}/visitas`
                        );
                        this.db
                          .collection(
                            `/personal/${regTabla.cod_vended}/rutas/${
                              this.service.id_ruta
                            }/periodos/${this.service.id_periodo}/visitas`
                          )
                          .valueChanges()
                          .subscribe((data: any) => {
                            console.log("trae personal de firebase", data);
                            this.visitas = data;
                            //   console.log('clasificando visitas 1');
                            this.visitas_cumplidas = this.visitas.filter(
                              reg => reg.estado === "C"
                            );
                            this.visitas_encurso = this.visitas.filter(
                              regc => regc.estado === "A"
                            );
                            this.visitas_pendientes = this.visitas.filter(
                              regP => regP.estado === "P" || regP.estado === ""
                            );
                          
                          //   onSearch() {
                          //     fechasFiltradas = this.myDates
                          //            .filter((date: Date) => pickerDate.getTime() < date.getTime() < pickerDate2.getTime());
                          //  }

                            this.visitas_cumplidas.forEach((visiData: any) => {
                              const fecierres = visiData.fechahora_cierre;
                              const fmiliseg = Date.parse(fecierres);
                              const fecierre = new Date(fmiliseg);
                              console.log('visitas cumplidas ', visiData);
                              console.log('vicumpli1 fecierre fmili', fecierres, fecierre);
                              const ano = fecierre.getFullYear();
                              const mes = fecierre.getMonth() + 1;
                              const dia = fecierre.getDate();
                              if ( this.resumano === ano.toString() && this.resummes === mes.toString() && this.resumdia === dia.toString()){
                                  this.visicumplidiaresum.push(visiData);
                              }
                            });  
                            console.log('visitas del dia', this.visicumplidiaresum);
                            if (!this.init) {
                              this.lat = data[0].latitud;
                              this.lng = data[0].longitud;
                              this.init = true;
                            }
                          });
                      } else {
                        console.log("ngOnInit home NO CARGO cargaPeriodoUsuar");
                      }
                    })
                    .catch(error => {
                      console.log("error en cargaPeriodoUsuar ", error);
                    });
                  var fecha = new Date();
                  var ano = fecha.getFullYear();
                  var mes = fecha.getMonth();
                  this.cargovendedor = true;
                  this.inicializaMonitor(regTabla);
                }
              },
              error => {
                this.showError(error);
              }
            );
        },
        error => {
          this.showError(error);
        }
      );
    });
  }

  inicializaMonitor(preg: any) {
    var lcontrol: any;
    var avalida = [];
    var lcontrol: any;
    this.cargando = true;
    this.resultados = false;
    var cbus = preg.cod_vended;
    this.filtrocotiza = "c.cod_vended='" + cbus + "'";
    console.log("this.filtrocotiza:" + this.filtrocotiza);
    // this.filtrocotiza=preg.id_cliepote.toString();
    // console.log("verCombocod_tercer ant getregtabla:" + lvalor);
    this.cargando = false;
    this.resultados = true;
  }
  //Si cambia el codigo del tercero llenar el nit con el mismo si este esta vacio
  onChanges(): void {}

  retornaRuta() {
    // console.log(this.rutamant);
    return "/" + this.rutamant;
  }

  onSubmit() {
    this.enerror = false;
    // this.grabo = false;
  }

  showError(msg) {
    this.message = msg;
    this.enerror = true;
    // console.log(this.message);
  }

  showMensaje(msg) {
    this.message = msg;
    this.enerror = false;
    // console.log(this.message);
  }

  retornaRutaAcampana() {
    // addregtbasica/VPARCOMPETENCIA
  }

  openconsulta(ptipo) {
    if (ptipo == "llamabusqueda") {
      this.llamabusqueda = true;
    }
  }
  public closeconsulta(ptipo) {}
  public closebusquellama(event) {
    console.log("en moni cliepote llega sde bus prod:" + event);
    this.pruellegallabusque = event;
    this.llamabusqueda = false;
  }

  openeditar(ptipo) {}
  public closeeditar(ptipo) {}

  //maneja el control para llamado adicion de tablas
  openadicion(ptipo) {
    if (ptipo == "cotiza") {
      this.crearcotiza = true;
    }
  }
  //maneja el control para cerrar

  public closeadicion(ptipo) {
    if (ptipo == "cotiza") {
      this.crearcotiza = false;
    }
  }

  conmutacollapse() {
    this.collapse = !this.collapse;
  }
  esconderpanel() {
    this.esconder = true;
  }

  cleanURL(oldURL: string) {
    return this.sanitizer.bypassSecurityTrustUrl(oldURL);
  }

  public monitorClick(dataItem): void {
    var pruta = `/monitorvisita/${dataItem.cod_tercer}/${
      this.regVendedor.cod_vended
    }/${dataItem.id_ruta}/${dataItem.id_reffecha}/${dataItem.id_visita}/`;
    // const lruta = `/personal/${regTabla.cod_vended}/rutas/${this.service.id_ruta}/periodos/${this.service.id_periodo}/visitas`;

    console.log("ir a monitor visita pruta:" + pruta);
    // this.router.navigate([pruta, dataItem]);
    this.router.navigate([pruta]);
  }
  retornaRutacotiza() {
    // console.log('ruta cotiza');
    // console.log('/cotizacion'+ '/VARPARCOTIZACRM_C/0' +  '/' + this.regCliepote.id_cliepote+ '/' + this.regCliepote.id_cliepote+'/A');
    return "/cotizacion" + "/VPARCOTIZACRM_C/0" + "/" + "0/" + "0/A/na/na";
  }
  //Trae años recorrido peronal
  public getanosrecorrido(ppersona: string) {
    return this.db
      .collection(`/personal/${ppersona}/recorrido`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }
  //Trae meses recorrido peronal
  public getmesesrecorrido(ppersona: string, ano: string) {
    return this.db
      .collection(`/personal/${ppersona}/recorrido/${ano}/meses`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }
  //Trae dias recorrido peronal
  public getdiasrecorrido(ppersona: string, ano: string, mes: string) {
    return this.db
      .collection(`/personal/${ppersona}/recorrido/${ano}/meses/${mes}/dias`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }

  //Trae historial recorrido peronal
  public gethistorialrecorrido(
    ppersona: string,
    ano: string,
    mes: string,
    dia: string
  ) {
    return this.db
      .collection(
        `/personal/${ppersona}/recorrido/${ano}/meses/${mes}/dias/${dia}/historial`
      ).valueChanges();
  //     .stateChanges()
  //     .pipe(
  //       map(actions =>
  //         actions.map(a => {
  //           console.log('hist statechange 1', a);
  //           const data = a.payload.doc.data();
  //           const id = a.payload.doc.id;
  //           console.log('hist statechange 1', id, data);
  //           return { id, ...data };
  //         })
  //       )
  //     );
  // }
  // /cambiar año de acuerdo al seleccionado
      }
  selecanorecorrido(ano) {
    this.historialrecorrido = [];
    this.recoano = ano.id.toString();
    console.log("cambio año a ", this.recoano);
    //cargar historial  ano mes dia seleccionado recorrido persona
    this.gethistorialrecorrido(
      this.pcod_vended,
      this.recoano,
      this.recmes,
      this.recdia
    ).subscribe((datoshis: any) => {
      console.log('act histo reco x ano', datoshis);
      this.historialrecorrido = datoshis;
      if (datoshis.lenght > 0) {
        this.latrecorrido = datoshis[0].latitud;
        this.lngrecorrido = datoshis[0].longitud;
        this.cargo_historialrecorido = true;
      }
    });
  }
  selecmesrecorrido(mes) {
    this.historialrecorrido = [];
    this.recmes = mes.id.toString();
    console.log("cambio mes a ", this.recmes);
    //cargar historial  ano mes dia seleccionado recorrido persona
    this.gethistorialrecorrido(
      this.pcod_vended,
      this.recoano,
      this.recmes,
      this.recdia
    ).subscribe((datoshis: any) => {
      console.log('act histo reco x mes', datoshis);
      this.historialrecorrido = datoshis;
      if (datoshis.lenght > 0) {
        this.latrecorrido = datoshis[0].latitud;
        this.lngrecorrido = datoshis[0].longitud;
        this.cargo_historialrecorido = true;
      }
    });
  }
  selecdiarecorrido(dia) {
    this.historialrecorrido = [];
    this.recdia = dia.id.toString();
    console.log("cambio dia a ", this.recdia);
    //cargar historial  ano mes dia seleccionado recorrido persona
    this.gethistorialrecorrido(
      this.pcod_vended,
      this.recoano,
      this.recmes,
      this.recdia
    ).subscribe((datoshis: any) => {
      console.log('act histo reco x dia', datoshis);
      if (datoshis.lenght > 0) {
        this.historialrecorrido = datoshis;
        this.latrecorrido = datoshis[0].latitud;
        this.lngrecorrido = datoshis[0].longitud;
        this.cargo_historialrecorido = true;
      }
    });
  }

  //Trae años resumen peronal
  public getanosresumen(ppersona: string) {
    return this.db
      .collection(`/personal/${ppersona}/resumdiario`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }
  //Trae meses resumen peronal
  public getmesesresumen(ppersona: string, ano: string) {
    console.log(ppersona,ano);
    return this.db
      .collection(`/personal/${ppersona}/resumdiario/${ano}/meses`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }
  //Trae dias resumen peronal
  public getdiasresumen(ppersona: string, ano: string, mes: string) {
    return this.db
      .collection(`/personal/${ppersona}/resumdiario/${ano}/meses/${mes}/dias`)
      .stateChanges()
      .pipe(
        map(actions =>
          actions.map(a => {
            const data = a.payload.doc.data();
            const id = a.payload.doc.id;
            return { id, ...data };
          })
        )
      );
  }

  //Trae cierrecaja resumen peronal
  public getcierrecajaresumen(
    ppersona: string,
    ano: string,
    mes: string,
    dia: string
  ) {
    return this.db
      .collection(
        `/personal/${ppersona}/resumdiario/${ano}/meses/${mes}/dias/${dia}/cierrecaja`
      ).valueChanges();
      }
  //Trae recibos resumen peronal
  public getrecibosresumen(
    ppersona: string,
    ano: string,
    mes: string,
    dia: string
  ) {
    return this.db
      .collection(
        `/personal/${ppersona}/resumdiario/${ano}/meses/${mes}/dias/${dia}/recibos`
      ).valueChanges();
      }

//Trae consignaciones resumen peronal
public getconsignacionesresumen(
  ppersona: string,
  ano: string,
  mes: string,
  dia: string
) {
  return this.db
    .collection(
      `/personal/${ppersona}/resumdiario/${ano}/meses/${mes}/dias/${dia}/consignaciones`
    ).valueChanges();
    }

      //actualiza cierre caja de firebas
  actcierrecajaresumen(){
    this.getcierrecajaresumen(
      this.pcod_vended,
      this.resumano,
      this.resummes,
      this.resumdia
    ).subscribe((datoshis: any) => {
      console.log('act cierre caja reco x ano', datoshis);
      this.cierrecajaresum = datoshis;
      this.clasificaCierre();
      this.cargo_cierrecajaresum = true;
    });
  }
  //actualiza recibos de firebas
  actrecibosresumen(){
    this.getrecibosresumen(
      this.pcod_vended,
      this.resumano,
      this.resummes,
      this.resumdia
    ).subscribe((datoshis: any) => {
      console.log('act recibos reco x ano', datoshis);
      this.recibosresum = datoshis;
      this.cargo_recibosresum = true;
    });
  }
//actualiza consignaciones de firebas
actconsignacionesresumen(){
  this.getconsignacionesresumen(
    this.pcod_vended,
    this.resumano,
    this.resummes,
    this.resumdia
  ).subscribe((datoshis: any) => {
    this.consignacionesresum = datoshis;
    console.log('act consig reco x ano', this.consignacionesresum);
    this.cargo_consignacionesresum = true;
  });
}

  selecanoresum(ano) {
    this.cierrecajaresum = [];
    this.resumano = ano.id.toString();
    console.log("cambio año a ", this.resumano);
    this.actcierrecajaresumen();
    this.actrecibosresumen();
    this.actconsignacionesresumen();
  }
  selecmesresum(mes) {
    this.cierrecajaresum = [];
    this.resummes = mes.id.toString();
    console.log("cambio mes a ", this.resummes);
    this.actcierrecajaresumen();
    this.actrecibosresumen();
    this.actconsignacionesresumen();
  }
  selecdiaresum(dia) {
    this.cierrecajaresum = [];
    this.resumdia = dia.id.toString();
    console.log("cambio dia a ", this.resumdia);
    this.actcierrecajaresumen();
    this.actrecibosresumen();
    this.actconsignacionesresumen();
  }

  linkrecibo(cod_docume,num_docume, fecha) {    
    const linkrecibo = "../EjeConsultaLis.wss?VRCod_obj=MONIDOCCONTA&VCAMPO=*E*&VCONDI=Especial&VTEXTO=PVXICOD_DOCUME='"
          + cod_docume+"',PVXINUM_DOCUME='"+num_docume+"',PVXIFECHA='" + this.service.fechacad(fecha) + "'";
          console.log('linkrecibo ', linkrecibo);
          return this.cleanURL(linkrecibo);
    }
  linkconsigna(cod_docume,num_docume, fecha) {    
      const linkconsig = "../EjeConsultaLis.wss?VRCod_obj=MONIDOCCONTA&VCAMPO=*E*&VCONDI=Especial&VTEXTO=PVXICOD_DOCUME='"
            + cod_docume+"',PVXINUM_DOCUME='"+num_docume+"',PVXIFECHA='" + this.service.fechacad(fecha) + "'";
            console.log('linkconsig ', linkconsig);
            return this.cleanURL(linkconsig);
      }
    onValuechangeverifica(value,recibo)
    {
      console.log('change verifica ',value,recibo );
      //Actualizar Verificado
      const idrecibo = recibo.cod_docume.trim() + recibo.num_docume.trim();
      const now = new Date();
      this.db
      .collection(
        `/personal/${this.regVendedor.cod_vended}/resumdiario/${this.resumano}/meses/${this.resummes}/dias/${this.resumdia}/recibos`
      )
      .doc(idrecibo)
      .update({ verificado: value,
         codusua_verifica: NetsolinApp.oapp.cuserid,
        nomusua_verifica: NetsolinApp.oapp.nomusuar,
        fecha_verifica: now});
    }
    onValuechangeverificaconsig(value,consig)
    {
      console.log('change verifica ',value,consig );
      //Actualizar Verificado
      const idconsig = consig.cod_docume.trim() + consig.num_docume.trim();
      const now = new Date();
      this.db
      .collection(
        `/personal/${this.regVendedor.cod_vended}/resumdiario/${this.resumano}/meses/${this.resummes}/dias/${this.resumdia}/consignaciones`
      )
      .doc(idconsig)
      .update({ verificado: value,
         codusua_verifica: NetsolinApp.oapp.cuserid,
        nomusua_verifica: NetsolinApp.oapp.nomusuar,
        fecha_verifica: now});
    }

    clasificaCierre() {
        this.cierrecajaefe = this.cierrecajaresum.filter(reg => reg.formpago === 'EFE');
        this.cierrecajachd = this.cierrecajaresum.filter(reg => reg.formpago === 'CHD');
        this.cierrecajapbcs = this.cierrecajaresum.filter(reg => reg.formpago === 'PBCS');
        this.cierrecajapbtr = this.cierrecajaresum.filter(reg => reg.formpago === 'PBTR');
    }
    totalforpago(arrayfp){
      let total = 0;
      if (arrayfp){
              if (arrayfp.length > 0) {
                arrayfp.forEach((val, i) => {
                  total += val.valor;
              });
          }
        }
      return total;
    }
    totalconsig(arrayfp){
      let total = 0;
      console.log('array asumar',arrayfp);
      if (arrayfp){
        if (arrayfp.length > 0) {
                arrayfp.forEach((val, i) => {
                  total += val.valor;
              });
          }
        }
      return total;
    }
    
}
