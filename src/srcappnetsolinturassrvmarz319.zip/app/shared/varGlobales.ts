import { Injectable } from '@angular/core';

@Injectable()
export class varGlobales {
  titulopag: string = '';
  rutaanterior: string = '';
  titrutaanterior: string = '';
  mostrarbreadcrumbs: boolean = true;
  obj_precio:string = 'RESTCONLISTPREC';
}